import os
import sys

import itk
import matplotlib
import matplotlib.pyplot as plt
import numpy as np


def main(input_filepath=os.path.join(os.path.dirname(__file__), '../Data/brain.png'),
         output_filepath='brain-connected_threshold.png', seedX=110, seedY=100, lower=190, upper=255):
    # Instantiate the reader
    input_image = itk.imread(input_filepath, pixel_type=itk.F)

    smoother = itk.GradientAnisotropicDiffusionImageFilter.New(Input=input_image, NumberOfIterations=20, TimeStep=0.04,
                                                               ConductanceParameter=3)

    smoother.Update()
    smoothed_image = smoother.GetOutput()

    # Display image with matplotlib to pick a coordinate
    plt.ion()
    plt.imshow(smoother.GetOutput(), cmap="gray")
    seedY, seedX = plt.ginput()[0]
    seedX, seedY = int(seedX), int(seedY)
    print("Seed coordinates : ", seedX, seedY)

    # Instantiate the filter

    lower = smoothed_image.GetPixel((seedX, seedY)) - 10
    upper = smoothed_image.GetPixel((seedX, seedY)) + 30

    print("initial value : ", smoothed_image.GetPixel((seedX, seedY)))
    print("lower, upper : ", lower, upper)

    # Configure filter from the command line arguments
    connected_threshold = itk.ConnectedThresholdImageFilter.New(smoothed_image)
    connected_threshold.SetReplaceValue(255)
    connected_threshold.SetLower(lower)
    connected_threshold.SetUpper(upper)

    connected_threshold.SetSeed((seedX, seedY))
    connected_threshold.Update()
    plt.ion()
    plt.imshow(itk.GetArrayViewFromImage(connected_threshold.GetOutput()), cmap="gray")
    plt.waitforbuttonpress()

    dimension = input_image.GetImageDimension()

    in_type = itk.output(connected_threshold)
    output_type = itk.Image[itk.UC, dimension]
    rescaler = itk.RescaleIntensityImageFilter[in_type, output_type].New(connected_threshold)
    rescaler.SetOutputMinimum(0)
    rescaler.SetOutputMaximum(255)
    rescaler.Update()

    itk.imwrite(rescaler, output_filepath)


if __name__ == "__main__":
    matplotlib.use('TkAgg')
    main(*sys.argv[1:])
