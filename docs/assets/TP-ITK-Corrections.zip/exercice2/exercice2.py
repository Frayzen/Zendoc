import itk
import os
import matplotlib
import matplotlib.pyplot as plt

matplotlib.use('TkAgg')
plt.ion()

input_filepath = "../Data/itklogo.jpg"

ImageType = itk.Image[itk.UC, 2]

# Question 1.
# reader = itk.ImageFileReader[ImageType].New()
# reader.SetFileName('../Data/itklogo.jpg'))
reader = itk.ImageFileReader[ImageType].New(FileName='../Data/itklogo.jpg')
reader.Update()
image = reader.GetOutput()

print(image.GetPixel((10, 10)))
# Question 2.
print(image.GetPixel((600, 133)))

# Question 3.
RGBPixelType = itk.RGBPixel[itk.ctype('unsigned char')]
ImageType = itk.Image[RGBPixelType, 2]

# Question 4 : Convenient method
image = itk.imread(input_filepath)
print(type(image))
plt.imshow(image, cmap='gray')
plt.waitforbuttonpress()
