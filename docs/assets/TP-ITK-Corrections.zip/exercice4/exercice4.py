import itk
import os

import matplotlib
from matplotlib import pyplot as plt

matplotlib.use('TkAgg')
plt.ion()

# Define the type
# PixelType = itk.RGBPixel[itk.ctype('unsigned char')]
# ImageType = itk.Image[PixelType, 2]
ImageType = itk.Image[itk.UC, 2]

# Read the image
reader = itk.ImageFileReader[ImageType].New()
reader.SetFileName(os.path.join(os.path.dirname(__file__), '../Data/itklogo.jpg'))


def detect_edges(input_filter, direction):
    gaussian_filter = itk.RecursiveGaussianImageFilter[ImageType, ImageType].New()
    gaussian_filter.SetInput(input_filter.GetOutput())
    gaussian_filter.SetSigma(1)
    gaussian_filter.SetOrder(1)
    gaussian_filter.SetDirection(direction)
    return gaussian_filter

f1 = detect_edges(reader, direction=0)
f1.Update()
plt.imshow(f1.GetOutput(), cmap='gray')
plt.waitforbuttonpress()

writer = itk.ImageFileWriter[ImageType].New()
writer.SetFileName('output_filter1.png')
writer.SetInput(f1.GetOutput())
writer.Update()

f2 = detect_edges(f1, direction=1)
f2.Update()
plt.imshow(f2.GetOutput(), cmap='gray')
plt.waitforbuttonpress()

# Write the image
writer.SetFileName('output_filter2.png')
writer.SetInput(f2.GetOutput())
writer.Update()
