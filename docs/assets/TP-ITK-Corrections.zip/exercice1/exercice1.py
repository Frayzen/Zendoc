import itk

print("I'm using ITK Version: ", itk.Version.GetITKVersion())
