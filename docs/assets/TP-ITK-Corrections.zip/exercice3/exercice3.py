import itk
import os
input_filename = '../Data/itklogo.jpg'

# Define the type
RGBPixelType = itk.RGBPixel[itk.ctype('unsigned char')]
# ImageType = itk.Image[RGBPixelType, 2]
ImageType = itk.Image[itk.UC, 2]

# Read the image
reader = itk.ImageFileReader[ImageType].New()
reader.SetFileName(input_filename)
reader.Update()
image = reader.GetOutput()

# Write the image
writer = itk.ImageFileWriter[ImageType].New()
writer.SetFileName('imagesortie.jpg')
writer.SetInput(image)
writer.Update()

writer.SetFileName('imagesortie.bmp')
writer.Update()

# Simpler code

image = itk.imread(input_filename)
itk.imwrite(image, input_filename)
