import vtk
import os

# Create the renderer, render window, and interactor
renderer = vtk.vtkRenderer()
render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)

iren = vtk.vtkRenderWindowInteractor()
iren.SetRenderWindow(render_window)

# Read the data from a SLC file
filePath = os.path.join(os.path.dirname(__file__), "../Data/poship.slc")
reader = vtk.vtkSLCReader()
reader.SetFileName(filePath)

# Create transfer functions for opacity and color
opacity_transfer_function = vtk.vtkPiecewiseFunction()
opacity_transfer_function.AddPoint(20, 0.0)
opacity_transfer_function.AddPoint(255, 0.3)

color_transfer_function = vtk.vtkColorTransferFunction()
color_transfer_function.AddRGBPoint(0.0, 0.0, 0.0, 0.0)
color_transfer_function.AddRGBPoint(64.0, 1.0, 0.0, 0.0)
color_transfer_function.AddRGBPoint(128.0, 0.0, 0.0, 1.0)
color_transfer_function.AddRGBPoint(192.0, 0.0, 1.0, 0.0)
color_transfer_function.AddRGBPoint(255.0, 0.0, 0.2, 0.0)

# Create properties, mappers, volume actors, and ray cast function
volume_property = vtk.vtkVolumeProperty()
volume_property.SetColor(color_transfer_function)
volume_property.SetScalarOpacity(opacity_transfer_function)

# Create the volume mapper
volume_mapper = vtk.vtkSmartVolumeMapper()
volume_mapper.SetInputConnection(reader.GetOutputPort())

# Create the volume and set the mapper and property
volume = vtk.vtkVolume()
volume.SetMapper(volume_mapper)
volume.SetProperty(volume_property)

# Add this volume to the renderer and get a closer look
renderer.AddActor(volume)
renderer.ResetCamera()
renderer.ResetCameraClippingRange()
renderer.SetBackground(0.1, 0.1, 0.3)

render_window.Render()

# Interact with the data at 3 frames per second
iren.SetDesiredUpdateRate(5.0)
# iren.SetStillUpdateRate(0.001)
iren.Start()
