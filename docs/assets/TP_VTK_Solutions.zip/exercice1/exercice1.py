import vtk

print("I'm using VTK Version: ", vtk.vtkVersion.GetVTKSourceVersion())
