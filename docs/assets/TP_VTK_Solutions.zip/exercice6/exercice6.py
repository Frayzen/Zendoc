import vtk
import os

# You'll need to read the file
reader = vtk.vtkXMLImageDataReader()

# You'll need a render window to show it in
renwin = vtk.vtkRenderWindow()

# You'll need a renderer in the render window
renderer = vtk.vtkRenderer()

# Set the file name on the reader to filename.c_str()
filePath = os.path.join(os.path.dirname(__file__), "../Data/head.vti")
reader.SetFileName(filePath)

# Put in renderer in the render window
renwin.AddRenderer(renderer)

# Create the interactor
interactor = vtk.vtkRenderWindowInteractor()
interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())

# Set the interactor on the render window
renwin.SetInteractor(interactor)

# Create a vtk.vtkContourFilter to do the isocontouring
# Set the input to the output of the reader
# Set the value to 135
contour = vtk.vtkContourFilter()
contour.SetInputConnection(reader.GetOutputPort())
contour.SetValue(0, 135)

# This is the vtk.vtkPolyDataMapper
contourMapper = vtk.vtkPolyDataMapper()

# Connect the mapper to the contour filter
# Remember to turn ScalarVisibilityOff()
contourMapper.SetInputConnection(contour.GetOutputPort())
contourMapper.ScalarVisibilityOff()

# This is the vtk.vtkActor
contourActor = vtk.vtkActor()

# Set the mapper
contourActor.SetMapper(contourMapper)

# Add the actor
renderer.AddActor(contourActor)

# Render and start the interactor
renwin.Render()
interactor.Start()
