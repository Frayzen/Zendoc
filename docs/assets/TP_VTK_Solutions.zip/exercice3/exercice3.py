import vtk
import os

# Read the data from a SLC file
filePath = os.path.join(os.path.dirname(__file__), "../Data/cow.vtk")
reader = vtk.vtkPolyDataReader()
reader.SetFileName(filePath)

# Triangulate
tri = vtk.vtkTriangleFilter()
tri.SetInputConnection(reader.GetOutputPort())

# Decimate
deci = vtk.vtkDecimatePro()
deci.SetInputConnection(tri.GetOutputPort())
deci.SetTargetReduction(0.3)
deci.PreserveTopologyOn()
deci.SetMaximumError(0.0002)

# Smooth
smooth = vtk.vtkSmoothPolyDataFilter()
smooth.SetInputConnection(deci.GetOutputPort())
smooth.SetNumberOfIterations(25)
smooth.SetRelaxationFactor(0.05)

normals = vtk.vtkPolyDataNormals()
normals.SetInputConnection(smooth.GetOutputPort())

# Rendering pipeline
mapper = vtk.vtkPolyDataMapper()
mapper.SetInputConnection(normals.GetOutputPort())
mapper.ScalarVisibilityOff()

actor = vtk.vtkActor()
actor.SetMapper(mapper)
actor.GetProperty().SetColor(255 / 255, 192 / 255, 203 / 255)

renderer = vtk.vtkRenderer()
renderer.AddActor(actor)

render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)

render_window_interactor = vtk.vtkRenderWindowInteractor()
render_window_interactor.SetRenderWindow(render_window)

render_window.Render()
render_window_interactor.Start()
