import vtk

points = vtk.vtkPoints()
points.SetNumberOfPoints(3)
points.SetPoint(0, 0.0, 0.0, 0.0)
points.SetPoint(1, 1.0, 0.0, 0.0)
points.SetPoint(2, 0.0, 1.0, 0.0)

cells = vtk.vtkCellArray()
cells.InsertNextCell(3)
cells.InsertCellPoint(0)
cells.InsertCellPoint(1)
cells.InsertCellPoint(2)

polydata = vtk.vtkPolyData()
polydata.SetPoints(points)
polydata.SetPolys(cells)

# Rendering pipeline
mapper = vtk.vtkPolyDataMapper()
mapper.SetInputData(polydata)

actor = vtk.vtkActor()
actor.SetMapper(mapper)

renderer = vtk.vtkRenderer()
renderer.AddActor(actor)

render_window = vtk.vtkRenderWindow()
render_window.AddRenderer(renderer)

render_window_interactor = vtk.vtkRenderWindowInteractor()
render_window_interactor.SetRenderWindow(render_window)

render_window.Render()
render_window_interactor.Start()
